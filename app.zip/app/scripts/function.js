// récuperation des Utilisateurs
function allUsers($http){

}
